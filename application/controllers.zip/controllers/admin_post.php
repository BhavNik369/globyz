<?php
class Admin_post extends CI_Controller {
 
 	const VIEW_FOLDER = 'admin/post';
    /**
    * Responsable for auto load the model
    * @return void
    */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('post_model');
        $this->load->model('users_model');

        if(!$this->session->userdata('is_logged_in')){
            redirect('admin/login');
        }
    }
 	/**
    * Load the main view with all the current model model's data.
    * @return void
    */
    public function index()
    {

        //all the posts sent by the view
        $users_id = $this->input->post('users_id');        
        $search_string = $this->input->post('search_string');        
        $order = $this->input->post('order'); 
        $order_type = $this->input->post('order_type'); 

        //pagination settings
        $config['per_page'] = 10;
        $config['base_url'] = base_url().'index.php/admin/post';
        $config['use_page_numbers'] = TRUE;
        $config['num_links'] = 20;
        $config['full_tag_open'] = '<ul>';
        $config['full_tag_close'] = '</ul>';
        $config['num_tag_open'] = '<li>';
        $config['num_tag_close'] = '</li>';
        $config['cur_tag_open'] = '<li class="active"><a>';
        $config['cur_tag_close'] = '</a></li>';

        //limit end
        $page = $this->uri->segment(3);

        //math to get the initial record to be select in the database
        $limit_end = ($page * $config['per_page']) - $config['per_page'];
        if ($limit_end < 0){
            $limit_end = 0;
        } 

        //if order type was changed
        if($order_type){
            $filter_session_data['order_type'] = $order_type;
        }
        else{
            //we have something stored in the session? 
            if($this->session->userdata('order_type')){
                $order_type = $this->session->userdata('order_type');    
            }else{
                //if we have nothing inside session, so it's the default "Asc"
                $order_type = 'Des';    
            }
        }
        //make the data type var avaible to our view
        $data['order_type_selected'] = $order_type;        
	
	
        //we must avoid a page reload with the previous session data
        //if any filter post was sent, then it's the first time we load the content
        //in this case we clean the session filter data
        //if any filter post was sent but we are in some page, we must load the session data

        //filtered && || paginated
        	
		
		if($users_id !== false && $search_string !== false && $order !== false || $this->uri->segment(3) == true){ 
           
            /*
            The comments here are the same for line 79 until 99

            if post is not null, we store it in session data array
            if is null, we use the session data already stored
            we save order into the the var to load the view with the param already selected       
            */
		
            if($users_id !== 0){
                $filter_session_data['users_selected'] = $users_id;
				
            }else{
                $users_id = $this->session->userdata('users_selected');
            	
			}
            
			$data['users_selected'] = $users_id;
			
			if($search_string){
                $filter_session_data['search_string_selected'] = $search_string;
            }else{
                $search_string = $this->session->userdata('search_string_selected');
            }
            $data['search_string_selected'] = $search_string;

            if($order){
                $filter_session_data['order'] = $order;
            }
            else{
                $order = $this->session->userdata('order');
            }
            $data['order'] = $order;

            //save session data into the session
            $this->session->set_userdata($filter_session_data);

            //fetch users data into arrays
            $data['users'] = $this->users_model->get_users();
			$data['count_post']= $this->post_model->count_post($users_id, $search_string, $order);
		    $config['total_rows'] = $data['count_post'];
	
            
			//fetch sql data into arrays
            
			if($search_string){
                if($order){
                    $data['post'] = $this->post_model->get_post($users_id, $search_string, $order, $order_type, $config['per_page'],$limit_end);        		}else{
                    $data['post'] = $this->post_model->get_post($users_id, $search_string, '', $order_type, $config['per_page'],$limit_end);           }
            }else{
                if($order){
                    $data['post'] = $this->post_model->get_post($users_id, '', $order, $order_type, $config['per_page'],$limit_end);        
                }else{
                    $data['post'] = $this->post_model->get_post($users_id, '', '', $order_type, $config['per_page'],$limit_end);        
                }
            }
	
        }else{
		 //clean filter data inside section
            $filter_session_data['users_selected'] = null;
            $filter_session_data['search_string_selected'] = null;
            $filter_session_data['order'] = null;
            $filter_session_data['order_type'] = null;
            $this->session->set_userdata($filter_session_data);

            //pre selected options
            $data['search_string_selected'] = '';
            $data['users_selected'] = 0;
            $data['order'] = 'id';

            //fetch sql data into arrays
            $data['users'] = $this->users_model->get_users();
            $data['count_post']= $this->post_model->count_post();
            $data['post'] = $this->post_model->get_post('', '', '', $order_type, $config['per_page'],$limit_end);        
           // var_dump($data['post']);
			
			$config['total_rows'] = $data['count_post'];

        }//!isset($manufacture_id) && !isset($search_string) && !isset($order)

        //initializate the panination helper 
        $this->pagination->initialize($config);   

        //load the view
        $data['main_content'] = 'admin/post/list';
        $this->load->view('includes/template', $data);  

    }//index

    public function add()
    {
        //if save button was clicked, get the data sent via post
        if ($this->input->server('REQUEST_METHOD') === 'POST')
        {

            //form validation
            $this->form_validation->set_rules('postTitle', 'postTitle', 'required');
            $this->form_validation->set_rules('genericName', 'genericName', 'required');
            $this->form_validation->set_rules('brandName', 'brandName', 'required');
            $this->form_validation->set_rules('formName', 'formName', 'required');
            $this->form_validation->set_rules('qty', 'qty', 'required');
            $this->form_validation->set_rules('price', 'price', 'required');
			$this->form_validation->set_rules('country', 'country', 'required');
            $this->form_validation->set_rules('lot', 'lot', 'required');
            $this->form_validation->set_error_delimiters('<div class="alert alert-error"><a class="close" data-dismiss="alert">×</a><strong>', '</strong></div>');

            //if the form has passed through the validation
            if ($this->form_validation->run())
            {
                $data_to_store = array(
                    'postTitle' => $this->input->post('postTitle'),
                    'genericName' => $this->input->post('genericName'),
                    'brandName' => $this->input->post('brandName'),
                    'formName' => $this->input->post('formName'),
                    'qty' => $this->input->post('qty'),          
                    'country' => $this->input->post('country'),
                    'lot' => $this->input->post('lot'),
                    'price' => $this->input->post('price')
                );
                //if the insert has returned true then we show the flash message
                if($this->post_model->store_product($data_to_store)){
                    $data['flash_message'] = TRUE; 
                }else{
                    $data['flash_message'] = FALSE; 
                }

            }

        }
        //fetch manufactures data to populate the select field
        $data['users'] = $this->users_model->get_users();
        //load the view
        $data['main_content'] = 'admin/post/add';
        $this->load->view('includes/template', $data);  
    }       

    /**
    * Update item by his id
    * @return void
    */
    public function update()
    {
        //product id 
        $id = $this->uri->segment(4);
  
        //if save button was clicked, get the data sent via post
        if ($this->input->server('REQUEST_METHOD') === 'POST')
        {
            //form validation
            $this->form_validation->set_rules('description', 'description', 'required');
            $this->form_validation->set_rules('stock', 'stock', 'required|numeric');
            $this->form_validation->set_rules('cost_price', 'cost_price', 'required|numeric');
            $this->form_validation->set_rules('sell_price', 'sell_price', 'required|numeric');
            $this->form_validation->set_rules('users_id', 'users_id', 'required');
            $this->form_validation->set_error_delimiters('<div class="alert alert-error"><a class="close" data-dismiss="alert">×</a><strong>', '</strong></div>');
            //if the form has passed through the validation
            if ($this->form_validation->run())
            {
    
                $data_to_store = array(
                    'description' => $this->input->post('description'),
                    'stock' => $this->input->post('stock'),
                    'cost_price' => $this->input->post('cost_price'),
                    'sell_price' => $this->input->post('sell_price'),          
                    'users_id' => $this->input->post('users_id')
                );
                //if the insert has returned true then we show the flash message
                if($this->post_model->update_product($id, $data_to_store) == TRUE){
                    $this->session->set_flashdata('flash_message', 'updated');
                }else{
                    $this->session->set_flashdata('flash_message', 'not_updated');
                }
                redirect('admin/post/update/'.$id.'');

            }//validation run

        }
		
		//if we are updating, and the data did not pass trough the validation
        //the code below wel reload the current data

        //product data 
        $data['product'] = $this->post_model->get_product_by_id($id);
        //fetch manufactures data to populate the select field
        $data['users'] = $this->users_model->get_users();
        //load the view
        $data['main_content'] = 'admin/post/edit';
        $this->load->view('includes/template', $data);            

    }//update
	
	public function postview()
    {
        $id = $this->uri->segment(4);
		
		$data['post'] = $this->post_model->get_post_by_id($id);
		
		$data['users'] = $this->users_model->get_users();
        //load the view
        
		$data['main_content'] = 'admin/post/postview';
        $this->load->view('includes/template', $data);            

    }
    /**
    * Delete product by his id
    * @return void
    */
    public function delete()
    {
        //product id 
        $id = $this->uri->segment(4);
        $this->post_model->delete_product($id);
        redirect('admin/post');
    }//edit

}